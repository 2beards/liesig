<?php include("../includes/layouts/header.php"); ?>

<link href="css/Dataism.css" rel="stylesheet" type="text/css">
























<div class="gridContainer clearfix">
  <div id="LayoutDiv1">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <div id="weeNav">
      <h66><a href="big_vid_play.php?query=Useless"> Useless</a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Sorrowful"> Sorrowful</a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Fearful"> Fearful</a></h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Attracted">Attracted</a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Angry">Angry</a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Peaceful"> Peaceful </a></h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Sure"> Sure </a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Energetic">Energetic </a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Animated"> Animated </a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Thrilled"> Thrilled </a> </h66>
      <p>&nbsp;</p>
      <h66><a href="big_vid_play.php?query=Lousy"> Lousy </a> </h66>
      <p>&nbsp;</p>
    </div>
    <div id="dataismtext">
            <p>
              <h345>
                To opaquely counter ubiquitous big data with individual unique stories. Dataism/datadadaism. Our exploration, our interest range from the experiments on those sounds only the under 25s can hear - the anti loitering alarms. To the rising tens of thousands in a football chanted stadia. To play, to explore the study of ASMR - the evolutionary mechanics of the bodily sounds and functions. Contact mics on wire fences, on windows, to the hums of the digital machines. To capture, to create, to record new compositions. Kandinsky, Malevich, Miró - our confidences, to visualise the study of sound and the shapes that affect our states, in our study of new forms of awareness.</h345>
            </p>
            <p>&nbsp; </p>
      <p><span style="color: red">In 1933</span> Poffenberger and Barrows explored how shapes and simple as lines could communicate emotions. Their theory was that when we look at a line our eyes move along the shape. This turns it into a physical experience that reminds us of the body language we use to express our emotions. They asked participants to match emotions form a line to each of the 18 curved and jagged lines sloping in different directions. A line going downwards was shown to make us feel “doleful,” while a “joyous” like takes our eyes upwards.</p>
      </p>
      <p>&nbsp;</p>

      <blockquote><h4567>Each of our emotions contains a whole range of feelings and these nuances can also be conveyed typographically. Psychologists Samuel Juni and Julie Gross asked 102 New York University students to read a satirical article from The New York Times. Each was given the reading randomly printed in either Arial or Times New Roman. Afterwards they were asked to rate their response to what they had read. They rated the article as being funnier and angrier, in other words more satirical, when it was read in Times New Roman.</h4567> </blockquote>
      
      <p>&nbsp;</p>
      
      <p>Type aswell as point line to plane can be seen as mirroring the emotions we display in the real world all through our facial expressions and gestures. When we are happy our faces become round with a wide smile and our body language is open. By contrast, an angry frown expression is pinched and angel and an attacking animal is all jagged teeth and claws. Let's integrate futuristic technology into the field of art therapy. it is time to add a digital realm to the practice.
      <p>&nbsp;</p>
      <div title="Page 1">
        <div>
          <div>
            <p>The intelligence of reductionism, the value of simplicity, the daring of simplicity.Our value comes from the principle of modesty,to quote the Roman poet Horace &ldquo;the Art lies in concealing the Art&rdquo;. </p>
            <p>&nbsp;</p>
            <p>Ergonomics and the Rams works of Braun is some of the embedded influence.The functionalist statement; form follows function is truth. Design aethetisis is important, partly because poorly designed objects slow us down and sadden us. It is a sign of miscommunication and a lack of empathy... Braun/Apple and very few others show us that capitalism need not to produce poor quality products. The psychologist literature suggests - that modesty stems from a lack of anxiety about being ignored...The boos, the fears in the audience of this conference were just, and I am sure expected, as that audience understood the power of not simplicity, but clarity. </p>
         
          </div>
        </div>
      </div>
<p>&nbsp;</p>
  
      
      <div id="socialmedia3">
      <img src="images/social_media_3_small_Black.svg">
     
      </div>
      
        <p>&nbsp;</p>
          <p>&nbsp;</p>
             <p>&nbsp;</p>
          <p>&nbsp;</p>
                    <p>&nbsp;</p>
             <p>&nbsp;</p>
         
      <p></p>
    </div>
  </div>
</div>

 <script src="respond.min.js"></script>
<script src="js/fastclick.js"></script>
  <script src="js/scroll.js"></script>
    
    
    
<?php include("../includes/layouts/footer.php"); ?>

