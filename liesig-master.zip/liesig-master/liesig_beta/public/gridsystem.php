<?php include("../includes/layouts/header.php"); ?>
<link href="css/the_grid_system.css"  rel="stylesheet" type="text/css">
<?php include("../includes/layouts/navbar.php"); ?>
    <section id="home">



<div class="gridContainer clearfix">
  <div id="LayoutDiv1">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp; </p>
    <div id="LayoutDiv3">
      <h66>Apathy </h66>
            <p>&nbsp;</p>
      <h66>Meloncholic </h66>
            <p>&nbsp;</p>
      <h66>Fear</h66>
            <p>&nbsp;</p>
      <h66>Lust </h66>
            <p>&nbsp;</p>
      <h66>Anger </h66>
            <p>&nbsp;</p>

      <h66>Peace </h66>
            <p>&nbsp;</p>

      <h66>Acceptance </h66>
            <p>&nbsp;</p>

      <h66>Fun      </h66>
                  <p>&nbsp;</p>

      <h66>Wild </h66>
                  <p>&nbsp;</p>

      <h66>Excitment </h66>
                  <p>&nbsp;</p>

      <h66>Sorrow     </h66>
                  <p>&nbsp;</p>

    </div>
    <div id="LayoutDiv13">
      <h101>In 1933 Poffenberger and Barrows explored how shapes and simple as lines could communicate emotions. Their theory was that when we look at a line our eyes move along the shape. This turns it into a physical experience that reminds us of the body language we use to express our emotions. They asked participants to match emotions form a line to each of the 18 curved and jagged lines sloping in different directions. A line going downwards was shown to make us feel “doleful,” while a “joyous” like takes our eyes upwards.</p>
        <p>&nbsp; </p>
      </h101>
    </div>
    <div id="LayoutDiv14"><h66>Filter by:</h66>    </div>
    
    
    <div id="LayoutDiv15">
      <h66>Page 1 of 2 | Next </h66></div>
    <div id="LayoutDiv2">
      
      <p><img src="images/testclip01.jpg" alt=""></p>
    <h66>Love<h/66>
    <p>Gushing, fawning, twilight, uplifting, unicorn, oucha, heart beat<br><br>by Tom  </p></div>
                  
                  
    <div id="LayoutDiv4">
    
    <p><img src="images/testclip02.jpg" ></p>
    <h66>Strong</h66><p>Uplift, pumpy, iron, spirit, soul, power, rise, alert, vigelliant, sure<br><br> by Tom </p></div>
              
              
    <div id="LayoutDiv5">
    
    <p><img src="images/testclip03.jpg"></p>
    <h66>Sensual</h66><p> Wanting, yearning, lust, seduction, sex, trouser snake, pom pom, <br><br> by Tom  </p></div>
                
                
    <div id="LayoutDiv8">
    
   <p><img src="images/testclip04.jpg" alt=""></p>
   <h66> Confused  </h66> <p> Perplexed, stupified, lost, java, unsure, wtf. Mysql <br> 
     <br>
    by Tom</p></div>


    <div id="LayoutDiv9">
      
       <p><img src="images/testclip05.jpg" alt=""></p>
      
      <h66>Angry</h66> <p>Fight, arragant, ignorant, obnoxious, corteson, football chant </p>
      <p><br> 
      </p>
    <p>by Tom  </p></div>
      
      
      
    <div id="LayoutDiv10"> 
    
    
    <p><img src="images/testclip06.jpg" alt=""></p>
      
    <h66>Indifferent </h66> <p>So, insensitive, dull, meh, nonchalance, but it's just fonts </p>
    <p>&nbsp;</p>
    <p>by Tom</p>
    </div>
    
    
    
    
    <div id="LayoutDiv16"> 
    
    <p><img src="images/testclip07.jpg" alt=""></p>
      <h66>Happy</h66>
      <p> Alergic to youth, teen, pop, blonde, airhead, cartoon <br><br>  by Tom    </p>
    </div>
      
      
      
    <div id="LayoutDiv17"> 
    
    <p><img src="images/testclip08.jpg" alt=""></p>
      <h66>Hurt</h66>
      <p>Meloncholic, drawn, board, toil, woe, pensive <br><br> by Tom</p></div>
      
      
      
    <div id="LayoutDiv18"> 
    
    <p><img src="images/testclip01.jpg" alt=""></p>
    <h66>Love<h/66> <p>Gushing, fawning, twilight, uplifting, unicorn, oucha, heart beat</p>
    <p>&nbsp;</p>
    <p>by Tom </p>
    </div>
    
    
    <div id="LayoutDiv19">
    
    <p><img src="images/testclip03.jpg"></p>
    <h66>Sensual</h66>
    <p> Wanting, yearning, lust, seduction, trouser snake, pom pom</p>
    <p>&nbsp;</p>
    <p>by Tom </p>
    </div>
    
    
    
    <div id="LayoutDiv20">
    
     <p><img src="images/testclip04.jpg" alt=""></p>
   <h66> Confused  </h66> <p> Perplexed, stupified, lost, java, unsure, wtf. Mysql <br>
     <br> 
    by Tom</p></div>

    
  
    
    <div id="LayoutDiv21">
    
    <p><img src="images/testclip05.jpg" alt=""></p>
      
      <h66>Angry</h66> <p>Fight, arragant, ignorant, obnoxious,  corteson, football chant </p>
      <p>&nbsp;</p>
      <p>by Tom </p>
    </div>
    
    
    
    
    <div id="LayoutDiv22"> 
    
    <p><img src="images/testclip06.jpg" alt=""></p>
      
    <h66>Indifferent </h66> <p>So, insensitive, dull, meh, nonchalance, but it's just fonts</p>
    <p> <br>
    </p>
    <p>by Tom</p>
    </div>
    
    
    
    <div id="LayoutDiv23"> 
    
    <p><img src="images/testclip07.jpg" alt=""></p>
      <h66>Happy</h66>
    <p> Alergic to youth, teen, pop, blonde, airhead, cartoon <br>
    </p>
    <p>&nbsp;</p>
    <p>by Tom    </p>
    </div>
    <div id="LayoutDiv24"> 
      
      <p><img src="images/testclip08.jpg" alt=""></p>
      <h66>Hurt</h66>
      <p>Meloncholic, Drawn, Board, Toil, Woe, Pensive</p>
      <p> <br>
      </p>
    <p>by Tom</p></div>



<div id="LayoutDiv25">

 <p><img src="images/testclip01.jpg" alt=""></p>
    <h66>Love<h/66> <p>Gushing, fawning, twilight, uplifting, unicorn, oucha, heart beat<br><br>by Tom  </p></div>
    
    
    
    <div id="LayoutDiv26"> 
    
    <p><img src="images/testclip03.jpg"></p>
    <h66>Sensual</h66><p> Wanting, yearning, lust, seduction, trouser snake, pom pom, <br><br> by Tom  </p></div>
    
    
    
    
    <div id="LayoutDiv27"> 
    
    <p><img src="images/testclip04.jpg" alt=""></p>
   <h66> Confused  </h66> <p> Perplexed, stupified, lost, java, unsure, wtf. Mysql <br>
     </p>
   <p><br>
     by Tom</p>
    </div>
    <div id="LayoutDiv29">
    <p>&nbsp;</p>

      <h14>
      LOAD MORE 
</h14>
      </div>
      
      
      
      
      
      
      
      
  </div>
  </div>
  </div>
  
</div>



 <script src="js/fastclick.js"></script>
  <script src="js/scroll.js"></script>
  <script src="js/fixed-responsive-nav.js"></script>
    


</div>
<?php include("../includes/layouts/footer.php"); ?>