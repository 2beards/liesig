(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 60,
	color: "#FFFFFF",
	webfonts: {},
	manifest: []
};



lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.Tween43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2.5,2,2).p("Ah8AAID5AA");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-1.2,27.7,2.5);


(lib.Tween41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.6,2,2).p("Ah7B8ID3j3");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-13.8,27.7,27.7);


(lib.Tween39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.7,2,2).p("AB8B8Ij3j3");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-13.8,27.7,27.7);


(lib.Tween37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.7,2,2).p("AjVDWIGrmr");
	this.shape.setTransform(0,0,0.663,0.663);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.6,-15.6,31.3,31.2);


(lib.Tween35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,2,2).p("AB8B8Ij3j3");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-13.8,27.7,27.7);


(lib.Tween33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.8).p("Ag9g9IA9ByIA+hyg");
	this.shape.setTransform(0.4,0.5,1,1,0,0,0,0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.7,-6.8,15.5,14.5);


(lib.Tween31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoAtQgUgSAAgbQAAgYATgRQASgSAXAAQAZAAASASQASASAAAXQAAAZgSASQgSARgZAAQgWAAgSgPgAgdgeQgNANAAARQAAATANAMQANANAQAAQASAAAMgNQANgNAAgSQAAgRgMgNQgNgNgSAAQgQAAgNANg");
	this.shape.setTransform(0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,-12.1,18,24.2);


(lib.Tween29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.8).p("AA+A+Ig+hyIg9Byg");
	this.shape.setTransform(0.1,-0.4,1,1,0,0,0,-0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.2,-7.6,15.5,14.5);


(lib.Tween27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoAtQgUgSAAgbQAAgYATgRQASgSAXAAQAZAAASASQASASAAAXQAAAZgSASQgSARgZAAQgWAAgSgPgAgdgeQgNANAAARQAAATANAMQANANAQAAQASAAAMgNQANgNAAgSQAAgRgMgNQgNgNgSAAQgQAAgNANg");
	this.shape.setTransform(0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,-12.1,18,24.2);


(lib.Tween25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgkgKIgOBOIgVAAIAciNIArBlIAvhlIAZCNIgUAAIgNhOIgnBUg");
	this.shape.setTransform(-5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.4,-13.4,30.9,26.8);


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgtAyQgXgTAAgfQAAgbAVgUQAUgUAbAAQAcAAAUAUQAVAUAAAbQgBAcgUAUQgVAUgbAAQgZAAgUgSgAgigiQgNAOAAAUQAAAVAOAOQAPAOASAAQAUAAAOgOQAOgOAAgVQAAgUgNgOQgPgOgUAAQgTAAgPAOg");
	this.shape.setTransform(-4.9,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.8,-13.4,29.7,26.8);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIBCIAAhwIgfAAIAAgTIBPAAIAAATIgeAAIAABwg");
	this.shape.setTransform(-5,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.2,-13.4,22.5,26.8);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIBCIAAiDIARAAIAACDg");
	this.shape.setTransform(-4.9,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.5,-13.4,19.2,26.8);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag5hGIAWAAIAjBaIAkhaIAWAAIg6CNg");
	this.shape.setTransform(-5,0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.9,-13.4,25.9,26.8);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAqBGIgOggIg2AAIgQAgIgVAAIA/iLIBACLgAAUATIgUgrIgSArIAmAAg");
	this.shape.setTransform(-4.9,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.4,-13.4,27,26.8);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIBCIAAhwIgfAAIAAgTIBPAAIAAATIgeAAIAABwg");
	this.shape.setTransform(-5,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.2,-13.4,22.5,26.8);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIBCIAAiDIARAAIAACDg");
	this.shape.setTransform(-4.9,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.5,-13.4,19.2,26.8);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgtAyQgXgTAAgfQAAgbAVgUQAUgUAbAAQAcAAAUAUQAVAUAAAbQgBAcgUAUQgVAUgbAAQgZAAgUgSgAgigiQgNAOAAAUQAAAVAOAOQAPAOASAAQAUAAAOgOQAOgOAAgVQAAgUgNgOQgPgOgUAAQgTAAgPAOg");
	this.shape.setTransform(-4.9,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.8,-13.4,29.7,26.8);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglgYIAABaIgUAAIAAiLIBfBjIAAhaIAUAAIAACKg");
	this.shape.setTransform(-5,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.4,-13.4,28.8,26.8);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbA6QgLgKgDgTIAUgEQACALADAFQAGAIAKAAQAJAAAHgGQAGgGAAgKIgBgHIgEgGIgGgFIgIgEIgLgFQgbgKAAgWQAAgPALgKQAMgKAPAAQAXAAAMAWIgQAKQgEgIgEgDQgFgCgGAAQgHAAgFAEQgGAFAAAHQAAAKAPAGIALAFQAQAHAHAHQAIAJAAAOQAAASgMAMQgNAMgRAAQgQAAgLgKg");
	this.shape.setTransform(-4.9,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.1,-13.4,24.2,26.8);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,2,2).p("Ah8AAID5AA");
	this.shape.setTransform(12.6,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,27.2,2);


// stage content:
(lib.RECOVER_RECOVER_MOTIVATIONS = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// l1
	this.instance = new lib.Tween43("synched",0);
	this.instance.setTransform(492.1,186,1.131,1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(140).to({_off:false},0).to({scaleX:1,x:479.9,y:190.3},139).wait(1));

	// r1
	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.setTransform(60.9,186,1.142,1.693,0,0,0,12.5,0);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(140).to({_off:false},0).to({scaleX:0.91,x:77.1,y:190.3},139).wait(1));

	// S
	this.instance_2 = new lib.Tween5("synched",0);
	this.instance_2.setTransform(438.1,185,1.474,1.474);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:432.7,y:188.3},139).wait(1));

	// N
	this.instance_3 = new lib.Tween7("synched",0);
	this.instance_3.setTransform(405.2,185,1.474,1.474);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:401.3,y:188.3},139).wait(1));

	// O
	this.instance_4 = new lib.Tween9("synched",0);
	this.instance_4.setTransform(368.3,185,1.474,1.474);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:365.2,y:188.3},139).wait(1));

	// I
	this.instance_5 = new lib.Tween11("synched",0);
	this.instance_5.setTransform(338.5,185,1.474,1.474);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:337.3,y:188.3},139).wait(1));

	// T
	this.instance_6 = new lib.Tween13("synched",0);
	this.instance_6.setTransform(314.1,185,1.474,1.474);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:315.5,y:188.3},139).wait(1));

	// A
	this.instance_7 = new lib.Tween15("synched",0);
	this.instance_7.setTransform(284.9,185,1.474,1.474);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:288.3,y:188.3},139).wait(1));

	// V
	this.instance_8 = new lib.Tween17("synched",0);
	this.instance_8.setTransform(253.8,185,1.474,1.474);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:258.8,y:188.3},139).wait(1));

	// I
	this.instance_9 = new lib.Tween19("synched",0);
	this.instance_9.setTransform(226.7,185,1.474,1.474);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:234.2,y:188.3},139).wait(1));

	// T
	this.instance_10 = new lib.Tween21("synched",0);
	this.instance_10.setTransform(202.3,185,1.474,1.474);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:212.4,y:188.3},139).wait(1));

	// O
	this.instance_11 = new lib.Tween23("synched",0);
	this.instance_11.setTransform(170.8,185,1.474,1.474);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:182.5,y:188.3},139).wait(1));

	// M
	this.instance_12 = new lib.Tween25("synched",0);
	this.instance_12.setTransform(132.4,185,1.474,1.474);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:144.7,y:188.3},139).wait(1));

	// O
	this.instance_13 = new lib.Tween27("synched",0);
	this.instance_13.setTransform(280.3,91,1.474,1.474);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(140).to({_off:false},0).to({scaleX:1.22,scaleY:1.22,x:280.5,y:109.2},139).wait(1));

	// A
	this.instance_14 = new lib.Tween29("synched",0);
	this.instance_14.setTransform(278.7,18.5,1.474,1.474);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(140).to({_off:false},0).to({scaleX:1.55,scaleY:1.55,x:279.5,y:32},139).wait(1));

	// O2
	this.instance_15 = new lib.Tween31("synched",0);
	this.instance_15.setTransform(280.1,284.3,1.474,1.474);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(140).to({_off:false},0).to({scaleX:1.24,scaleY:1.24,x:281.1,y:274.2},139).wait(1));

	// A2
	this.instance_16 = new lib.Tween33("synched",0);
	this.instance_16.setTransform(279.4,361,1.474,1.474);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(140).to({_off:false},0).to({scaleX:1.44,scaleY:1.44,x:280.3,y:348.9},139).wait(1));

	// TOP RIGHT
	this.instance_17 = new lib.Tween37("synched",0);
	this.instance_17.setTransform(367.6,97.9,2.329,2.329);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:374.9,y:91.8},139).wait(1));

	// Layer 114
	this.instance_18 = new lib.Tween41("synched",0);
	this.instance_18.setTransform(184.9,278.8,2.724,2.724);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:175.3,y:292.7},139).wait(1));

	// Layer 115
	this.instance_19 = new lib.Tween39("synched",0);
	this.instance_19.setTransform(368.6,278.9,2.757,2.757);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(140).to({_off:false},0).to({scaleX:1.69,scaleY:1.69,x:379.4,y:292.7},139).wait(1));

	// TopLeftLine
	this.instance_20 = new lib.Tween35("synched",0);
	this.instance_20.setTransform(188.8,97.5,2.595,2.595);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(140).to({_off:false},0).to({scaleX:1.88,scaleY:1.88,x:179.6,y:91.3},139).wait(1));

	// l1
	this.instance_21 = new lib.Tween43("synched",0);
	this.instance_21.setTransform(479.9,190.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).to({scaleX:1.13,x:492.1,y:186},139).to({_off:true},1).wait(140));

	// r1
	this.instance_22 = new lib.Symbol2("synched",0);
	this.instance_22.setTransform(77.1,190.3,0.912,1.693,0,0,0,12.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).to({scaleX:1.14,x:60.9,y:186},139).to({_off:true},1).wait(140));

	// S
	this.instance_23 = new lib.Tween5("synched",0);
	this.instance_23.setTransform(432.7,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).to({scaleX:1.47,scaleY:1.47,x:438.1,y:185},139).to({_off:true},1).wait(140));

	// N
	this.instance_24 = new lib.Tween7("synched",0);
	this.instance_24.setTransform(401.3,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).to({scaleX:1.47,scaleY:1.47,x:405.2,y:185},139).to({_off:true},1).wait(140));

	// O
	this.instance_25 = new lib.Tween9("synched",0);
	this.instance_25.setTransform(365.2,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).to({scaleX:1.47,scaleY:1.47,x:368.3,y:185},139).to({_off:true},1).wait(140));

	// I
	this.instance_26 = new lib.Tween11("synched",0);
	this.instance_26.setTransform(337.3,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_26).to({scaleX:1.47,scaleY:1.47,x:338.5,y:185},139).to({_off:true},1).wait(140));

	// T
	this.instance_27 = new lib.Tween13("synched",0);
	this.instance_27.setTransform(315.5,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).to({scaleX:1.47,scaleY:1.47,x:314.1,y:185},139).to({_off:true},1).wait(140));

	// A
	this.instance_28 = new lib.Tween15("synched",0);
	this.instance_28.setTransform(288.3,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).to({scaleX:1.47,scaleY:1.47,x:284.9,y:185},139).to({_off:true},1).wait(140));

	// V
	this.instance_29 = new lib.Tween17("synched",0);
	this.instance_29.setTransform(258.8,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_29).to({scaleX:1.47,scaleY:1.47,x:253.8,y:185},139).to({_off:true},1).wait(140));

	// I
	this.instance_30 = new lib.Tween19("synched",0);
	this.instance_30.setTransform(234.2,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_30).to({scaleX:1.47,scaleY:1.47,x:226.7,y:185},139).to({_off:true},1).wait(140));

	// T
	this.instance_31 = new lib.Tween21("synched",0);
	this.instance_31.setTransform(212.4,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_31).to({scaleX:1.47,scaleY:1.47,x:202.3,y:185},139).to({_off:true},1).wait(140));

	// O
	this.instance_32 = new lib.Tween23("synched",0);
	this.instance_32.setTransform(182.5,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_32).to({scaleX:1.47,scaleY:1.47,x:170.8,y:185},139).to({_off:true},1).wait(140));

	// M
	this.instance_33 = new lib.Tween25("synched",0);
	this.instance_33.setTransform(144.7,188.3,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_33).to({scaleX:1.47,scaleY:1.47,x:132.4,y:185},139).to({_off:true},1).wait(140));

	// O
	this.instance_34 = new lib.Tween27("synched",0);
	this.instance_34.setTransform(280.5,109.2,1.223,1.223);

	this.timeline.addTween(cjs.Tween.get(this.instance_34).to({scaleX:1.47,scaleY:1.47,x:280.3,y:91},139).to({_off:true},1).wait(140));

	// A
	this.instance_35 = new lib.Tween29("synched",0);
	this.instance_35.setTransform(279.5,32,1.547,1.547);

	this.timeline.addTween(cjs.Tween.get(this.instance_35).to({scaleX:1.47,scaleY:1.47,x:278.7,y:18.5},139).to({_off:true},1).wait(140));

	// O2
	this.instance_36 = new lib.Tween31("synched",0);
	this.instance_36.setTransform(281.1,274.2,1.236,1.236);

	this.timeline.addTween(cjs.Tween.get(this.instance_36).to({scaleX:1.47,scaleY:1.47,x:280.1,y:284.3},139).to({_off:true},1).wait(140));

	// A2
	this.instance_37 = new lib.Tween33("synched",0);
	this.instance_37.setTransform(280.3,348.9,1.443,1.443);

	this.timeline.addTween(cjs.Tween.get(this.instance_37).to({scaleX:1.47,scaleY:1.47,x:279.4,y:361},139).to({_off:true},1).wait(140));

	// TOP RIGHT
	this.instance_38 = new lib.Tween37("synched",0);
	this.instance_38.setTransform(374.9,91.8,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_38).to({scaleX:2.33,scaleY:2.33,x:367.6,y:97.9},139).to({_off:true},1).wait(140));

	// Layer 44
	this.instance_39 = new lib.Tween41("synched",0);
	this.instance_39.setTransform(175.3,292.7,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_39).to({scaleX:2.72,scaleY:2.72,x:184.9,y:278.8},139).to({_off:true},1).wait(140));

	// Layer 43
	this.instance_40 = new lib.Tween39("synched",0);
	this.instance_40.setTransform(379.4,292.7,1.693,1.693);

	this.timeline.addTween(cjs.Tween.get(this.instance_40).to({scaleX:2.76,scaleY:2.76,x:368.6,y:278.9},139).to({_off:true},1).wait(140));

	// TopLeftLine
	this.instance_41 = new lib.Tween35("synched",0);
	this.instance_41.setTransform(179.6,91.3,1.877,1.877);

	this.timeline.addTween(cjs.Tween.get(this.instance_41).to({scaleX:2.6,scaleY:2.6,x:188.8,y:97.5},139).to({_off:true},1).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(339.4,220.2,429.3,339.8);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;