<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="">
<!--<![endif]-->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Liesig-submit</title>






<?php include("../includes/layouts/header.php"); ?>

<link href="css/upload.css" rel="stylesheet" type="text/css">

<?php include("../includes/layouts/navbar.php"); ?>  



<div id="audiohohoh">

<form action="uploader.php" method="post" enctype="multipart/form-data">
    <p>From an hour of football chants<br>
    to most hedonistic of <br>
    to contact mics in srange, strange places...<br>
Please ensure that taste levels are meet,<br>
and you have the understanding that:<br>
Thou. shall not. bore.</p>
      <h123>Select your audio to upload:</h123>
    </p>
    <p>
    <input type="file" name="fileToUpload" id="fileToUpload" required>*</p>
    <p><br>
       <h123> Tag the audio with moods (1 or more)<br>
         <br>
         <input type="text" name="tag1" placeholder="tag1" required>*<br>
         <input type="text" name="tag2" placeholder="tag2"><br>
         <input type="text" name="tag3" placeholder="tag3">
         <br>
         <br>
      </h123>
       <h123>Artist Name  </h123>
      <input type="text" name="artist" placeholder="Artist" required>*<br>
       <h123> Audio Title  </h123>
    <input type="text" name="title" placeholder="Title" required>*</p>
    <p>Please ensure that your submission<br>
    is Creative Commons.<br>
    <p>This is a parciritory Art experiment</p>
    <p><br>
      <input type="submit" value="Upload Audio" name="submit">
    </p>
    <p>
      <h223>fields marked with * are required   </h223>
      </p>
      <p>&nbsp;</p>
    <p>&nbsp;</p>
</form>
</div>






 <script src="respond.min.js"></script>
<script src="js/fastclick.js"></script>
  <script src="js/scroll.js"></script>












<?php include("../includes/layouts/footer.php"); ?>  
