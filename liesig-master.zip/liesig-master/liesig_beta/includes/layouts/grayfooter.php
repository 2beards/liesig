<div id="LayoutDiv13"><h89>      <p>&nbsp;</p>
<a href="../../../../~s0937900/Liesig/Liesig_Report_001.pdf">  Liesig Alpha Report </a><p>&nbsp;</p>
Created by two & &frac12; Beards <br><h90>UoEd ECA MSc </h90> <br>
<img src="images/social_media_3_small.png"></div>


<script src="js/fastclick.js"></script>
    <script src="js/scroll.js"></script>
    <script src="js/fixed-responsive-nav.js"></script>
    

</body>
</html>
